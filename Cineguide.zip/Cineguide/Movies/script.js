
// Mobile menu toggle functionality
const menuButton = document.getElementById("menu-button");
const mobileMenu = document.getElementById("mobile-menu");
const closeButton = document.getElementById("close-button");

// Toggle the mobile menu when icon is clicked
menuButton.onclick = () => {
    mobileMenu.classList.toggle("translate-x-full");
};

// Close the mobile menu when the close button is clicked
closeButton.onclick = () => {
    mobileMenu.classList.add("translate-x-full");
};

const apiKey = '1789f687965581723d153630c6153e6b';

// Select movie results container
const movieResults = document.getElementById('movie-results');

async function fetchMovies() {
    const url = `https://api.themoviedb.org/3/trending/movie/day?api_key=${apiKey}&language=en-US`;

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.results && data.results.length > 0) {
            displayMovies(data.results);
        } else {
            movieResults.innerHTML = '<p>No Movies found. Try again later.</p>';
        }
    } catch (error) {
        console.error('Error fetching data:', error);
        movieResults.innerHTML = '<p>There was an error fetching data.</p>';
    }
}

// function displayMovies(movies) {
//     movieResults.innerHTML = '';

//     // Get screen size and set movie limit
//     let movieLimit = 6; // Default for small and medium screens
//     if (window.innerWidth > 1024) {
//         movieLimit = 10; // Large screens
//     }

//     // Slice the movies array based on the screen size
//     const displayedMovies = movies.slice(0, movieLimit);

//     displayedMovies.forEach(movie => {
//         const movieDiv = document.createElement('div');
//         movieDiv.classList.add(
//             'rounded-lg', 'overflow-hidden', 'shadow-lg', 'border', 'border-yellow-400',
//             'w-1/2', 'sm:w-1/3', 'md:w-1/4', 'lg:w-1/5', 'p-2'
//         );

//         const movieCard = document.createElement('div');

//         // Movie poster
//         const moviePoster = document.createElement('img');
//         moviePoster.src = movie.poster_path
//             ? `https://image.tmdb.org/t/p/original${movie.poster_path}`
//             : 'https://via.placeholder.com/500x750?text=No+Poster';
//         moviePoster.alt = movie.original_title;
//         moviePoster.classList.add('w-full', 'h-32', 'object-cover', 'hover:opacity-75', 'rounded-lg', 'sm:h-72');

//         // Movie title
//         const movieTitle = document.createElement('h3');
//         movieTitle.textContent = movie.original_title;
//         movieTitle.classList.add('text-yellow-600', 'font-bold', 'mt-4', 'text-center', 'text-lg', 'line-clamp-2');

//         // Movie release date
//         const movieReleaseDate = document.createElement('p');
//         movieReleaseDate.textContent = movie.release_date || 'Release date not available';
//         movieReleaseDate.classList.add('text-white', 'text-sm', 'mt-2', 'text-center');

//         movieCard.appendChild(moviePoster);
//         movieCard.appendChild(movieTitle);
//         movieCard.appendChild(movieReleaseDate);
//         movieDiv.appendChild(movieCard);
//         movieResults.appendChild(movieDiv);
//     });
// }







function displayMovies(movies) {
    movieResults.innerHTML = '';

    let movieLimit = window.innerWidth > 1024 ? 10 : 6;
    const displayedMovies = movies.slice(0, movieLimit);

    displayedMovies.forEach(movie => {
        const movieDiv = document.createElement('div');
        movieDiv.classList.add('rounded-lg', 'overflow-hidden', 'shadow-lg', 'border', 'border-yellow-400', 'p-2');

        // ✅ Wrap movie in <a> tag to make it clickable
        const movieLink = document.createElement('a');
        movieLink.href = `../Details/details.html?type=movie&id=${movie.id}`; // Pass movie ID in URL
        movieLink.classList.add('block');

        const moviePoster = document.createElement('img');
        moviePoster.src = movie.poster_path
            ? `https://image.tmdb.org/t/p/original${movie.poster_path}`
            : 'https://via.placeholder.com/500x750?text=No+Poster';
        moviePoster.alt = movie.title;
        moviePoster.classList.add('w-full', 'h-32', 'object-cover', 'hover:opacity-75', 'rounded-lg', 'sm:h-72');

        const movieTitle = document.createElement('h3');
        movieTitle.textContent = movie.title;
        movieTitle.classList.add('text-yellow-600', 'font-bold', 'mt-4', 'text-center', 'text-lg');

        movieLink.appendChild(moviePoster);
        movieLink.appendChild(movieTitle);
        movieDiv.appendChild(movieLink);
        movieResults.appendChild(movieDiv);
    });
}








// Fetch movies on page load
document.addEventListener('DOMContentLoaded', fetchMovies);

// Update movie list on window resize
window.addEventListener('resize', fetchMovies);

//trending Movies section ends




//search functionality starts here
const searchinput = document.getElementById('searchInput');
const searchbtn = document.getElementById('searchBtn');

searchinput.addEventListener('keypress', function (event) {
    if (event.key === 'Enter') {
        searchMovie(searchinput.value.trim());
    }
})
searchbtn.addEventListener('click', function (event) {
    searchMovie(searchinput.value.trim());

})

async function searchMovie(query) {
    if (!query) return; // Don't search empty queries

    const url = `https://api.themoviedb.org/3/search/movie?api_key=${apiKey}&query=${query}`;
    const movietag = document.getElementById('movieTag');
    movietag.classList.add("font-semibold")

    movietag.innerHTML = `&nbsp; &nbsp;Results For '${query}' &nbsp;`

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.results && data.results.length > 0) {

            displayMovies(data.results);
        } else {
            movieResults.innerHTML = '<p class="text-yellow-400 text-center">No results found.</p>';
        }
    } catch (error) {
        console.error('Error fetching movie:', error);
        movieResults.innerHTML = '<p class="text-red-500 text-center">Error fetching movie.</p>';
    }
}




//search functionality ends here