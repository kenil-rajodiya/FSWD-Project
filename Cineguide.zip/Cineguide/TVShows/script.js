
// Mobile menu toggle functionality
const menuButton = document.getElementById("menu-button");
const mobileMenu = document.getElementById("mobile-menu");
const closeButton = document.getElementById("close-button");

// Toggle the mobile menu when icon is clicked
menuButton.onclick = () => {
    mobileMenu.classList.toggle("translate-x-full");
};

// Close the mobile menu when the close button is clicked
closeButton.onclick = () => {
    mobileMenu.classList.add("translate-x-full");
};

const apiKey = '1789f687965581723d153630c6153e6b';

// Select movie results container
const showResults = document.getElementById('shows-results');

async function fetchShows() {
    const url = `https://api.themoviedb.org/3/trending/tv/week?api_key=${apiKey}&language=en-US`;

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.results && data.results.length > 0) {
            console.log(data.results);

            displayShows(data.results);
        } else {
            showResults.innerHTML = '<p>No Movies found. Try again later.</p>';
        }
    } catch (error) {
        console.error('Error fetching data:', error);
        showResults.innerHTML = '<p>There was an error fetching data.</p>';
    }
}

// function displayShows(shows) {
//     showResults.innerHTML = '';

//     // Get screen size and set movie limit
//     let showLimit = 6; // Default for small and medium screens
//     if (window.innerWidth > 1024) {
//         showLimit = 10; // Large screens
//     }

//     // Slice the movies array based on the screen size
//     const displayedShows = shows.slice(0, showLimit);

//     displayedShows.forEach(show => {
//         const showDiv = document.createElement('div');
//         showDiv.classList.add(
//             'rounded-lg', 'overflow-hidden', 'shadow-lg', 'border', 'border-yellow-400',
//             'w-1/2', 'sm:w-1/3', 'md:w-1/4', 'lg:w-1/5', 'p-2'
//         );

//         const showCard = document.createElement('div');

//         // Movie poster
//         const showPoster = document.createElement('img');
//         showPoster.src = show.poster_path
//             ? `https://image.tmdb.org/t/p/original${show.poster_path}`
//             : 'https://via.placeholder.com/500x750?text=No+Poster';
//         showPoster.alt = show.original_name;
//         showPoster.classList.add('w-full', 'h-32', 'object-cover', 'hover:opacity-75', 'rounded-lg', 'sm:h-72');

//         // Movie title
//         const showTitle = document.createElement('h3');
//         showTitle.textContent = show.original_name;
//         showTitle.classList.add('text-yellow-600', 'font-bold', 'mt-4', 'text-center', 'text-lg', 'line-clamp-2');

//         // Movie release date
//         const showReleaseDate = document.createElement('p');
//         showReleaseDate.textContent = show.first_air_date || 'Release date not available';
//         showReleaseDate.classList.add('text-white', 'text-sm', 'mt-2', 'text-center');

//         showCard.appendChild(showPoster);
//         showCard.appendChild(showTitle);
//         showCard.appendChild(showReleaseDate);
//         showDiv.appendChild(showCard);
//         showResults.appendChild(showDiv);
//     });
// }
















function displayShows(shows) {
    showResults.innerHTML = '';

    let showLimit = window.innerWidth > 1024 ? 10 : 6;
    const displayedShows = shows.slice(0, showLimit);

    displayedShows.forEach(show => {
        const showDiv = document.createElement('div');
        showDiv.classList.add('rounded-lg', 'overflow-hidden', 'shadow-lg', 'border', 'border-yellow-400', 'p-2');

        // ✅ Wrap show in <a> tag to make it clickable
        const showLink = document.createElement('a');
        showLink.href = `../Details/details.html?type=tv&id=${show.id}`; // Pass TV Show ID in URL
        showLink.classList.add('block');

        const showPoster = document.createElement('img');
        showPoster.src = show.poster_path
            ? `https://image.tmdb.org/t/p/original${show.poster_path}`
            : 'https://via.placeholder.com/500x750?text=No+Poster';
        showPoster.alt = show.name;
        showPoster.classList.add('w-full', 'h-32', 'object-cover', 'hover:opacity-75', 'rounded-lg', 'sm:h-72');

        const showTitle = document.createElement('h3');
        showTitle.textContent = show.name;
        showTitle.classList.add('text-yellow-600', 'font-bold', 'mt-4', 'text-center', 'text-lg');

        showLink.appendChild(showPoster);
        showLink.appendChild(showTitle);
        showDiv.appendChild(showLink);
        showResults.appendChild(showDiv);
    });
}


















// Fetch movies on page load
document.addEventListener('DOMContentLoaded', fetchShows);

// Update movie list on window resize
window.addEventListener('resize', fetchShows);

//trending Movies section ends




//search functionality starts here
const searchinput = document.getElementById('searchInput');
const searchbtn = document.getElementById('searchBtn');

searchinput.addEventListener('keypress', function (event) {
    if (event.key === 'Enter') {
        searchMovie(searchinput.value.trim());
    }
})
searchbtn.addEventListener('click', function (event) {
    searchMovie(searchinput.value.trim());

})

async function searchMovie(query) {
    if (!query) return; // Don't search empty queries

    const url = `https://api.themoviedb.org/3/search/tv?api_key=${apiKey}&query=${query}`;
    const movietag = document.getElementById('showTag');
    movietag.classList.add("font-semibold")

    movietag.innerHTML = `&nbsp; &nbsp;Results For '${query}' &nbsp;`

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.results && data.results.length > 0) {

            displayShows(data.results);
        } else {
            showResults.innerHTML = '<p class="text-yellow-400 text-center">No results found.</p>';
        }
    } catch (error) {
        console.error('Error fetching movie:', error);
        showResults.innerHTML = '<p class="text-red-500 text-center">Error fetching movie.</p>';
    }
}




//search functionality ends here