const apiKey = '1789f687965581723d153630c6153e6b';

// Mobile menu toggle functionality
const menuButton = document.getElementById("menu-button");
const mobileMenu = document.getElementById("mobile-menu");
const closeButton = document.getElementById("close-button");

// Toggle the mobile menu when icon is clicked
menuButton.onclick = () => {
    mobileMenu.classList.toggle("translate-x-full");
};

// Close the mobile menu when the close button is clicked
closeButton.onclick = () => {
    mobileMenu.classList.add("translate-x-full");
};




//trending Movies section starts here
const movieResults = document.getElementById('movie-results');

async function fetchMovies() {
    const url = `https://api.themoviedb.org/3/trending/movie/day?api_key=${apiKey}&language=en-US`;

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.results && data.results.length > 0) {
            displayMovies(data.results);
        } else {
            movieResults.innerHTML = '<p>No Movies found. Try again later.</p>';
        }
    } catch (error) {
        console.error('Error fetching data:', error);
        movieResults.innerHTML = '<p>There was an error fetching data.</p>';
    }
}


function displayMovies(movies) {
    const movieResults = document.getElementById('movie-results');
    movieResults.innerHTML = '';

    movies.forEach(movie => {
        const movieDiv = document.createElement('div');
        movieDiv.classList.add(
            'rounded-lg', 'overflow-hidden', 'shadow-lg', 'snap-center',
            'mr-2', 'ml-2', 'border', 'border-yellow-400', 'lg:mr-3', 'lg:ml-3'
        );

        // ✅ Wrap movie in an <a> tag to make it clickable
        const movieLink = document.createElement('a');
        movieLink.href = `../Details/details.html?type=movie&id=${movie.id}`;
        movieLink.classList.add('block'); // Ensures the entire card is clickable

        const movieCard = document.createElement('div');

        // Movie poster
        const moviePoster = document.createElement('img');
        moviePoster.src = movie.poster_path
            ? `https://image.tmdb.org/t/p/original${movie.poster_path}`
            : 'https://via.placeholder.com/500x750?text=No+Poster';

        moviePoster.alt = movie.original_title;
        moviePoster.classList.add('w-full', 'h-32', 'object-cover', 'hover:opacity-75', 'rounded-lg', 'sm:h-72');

        // Movie title
        const movieTitle = document.createElement('h3');
        movieTitle.textContent = movie.original_title;
        movieTitle.classList.add('text-yellow-600', 'font-bold', 'mt-4', 'text-center', 'movie-title', 'text-xl', 'line-clamp-2');

        // Movie release date
        const movieReleaseDate = document.createElement('p');
        movieReleaseDate.textContent = movie.release_date || 'Release date not available';
        movieReleaseDate.classList.add('text-white', 'text-sm', 'mt-2', 'text-center', 'sm:mb-2', 'mb-1');

        // Append elements
        movieCard.appendChild(moviePoster);
        movieCard.appendChild(movieTitle);
        movieCard.appendChild(movieReleaseDate);

        // ✅ Ensure clicking anywhere on the card opens the details page
        movieLink.appendChild(movieCard);
        movieDiv.appendChild(movieLink);
        movieResults.appendChild(movieDiv);
    });
}

document.addEventListener('DOMContentLoaded', fetchMovies);

//trending Movies section ends





//trending tv shows section starts here
const showsResults = document.getElementById('shows-results');

async function fetchShows() {
    const url = `https://api.themoviedb.org/3/trending/tv/week?api_key=${apiKey}&language=en-US`;
    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.results && data.results.length > 0) {
            displayShows(data.results);
        } else {
            showsResults.innerHTML = '<p>No TV shows found. Try again later.</p>';
        }
    } catch (error) {
        console.error('Error fetching data:', error);
        showsResults.innerHTML = '<p>There was an error fetching data.</p>';
    }
}

// function displayShows(shows) {
//     const showsResults = document.getElementById('shows-results');
//     showsResults.innerHTML = '';

//     shows.forEach(show => {
//         const showDiv = document.createElement('div');
//         showDiv.classList.add('rounded-lg', 'overflow-hidden', 'shadow-lg', 'snap-center', 'mr-2', 'ml-2', 'border', 'border-yellow-400', 'lg:mr-3', 'lg:ml-3');

//         const showCard = document.createElement('div');

//         const showPoster = document.createElement('img');
//         showPoster.src = show.poster_path
//             ? `https://image.tmdb.org/t/p/original${show.poster_path}`
//             : 'https://via.placeholder.com/500x750?text=No+Poster';

//         showPoster.alt = show.name;
//         showPoster.classList.add('w-full', 'h-32', 'object-cover', 'hover:opacity-75', 'rounded-lg', 'sm:h-72');

//         const showTitle = document.createElement('h3');
//         showTitle.textContent = show.name;
//         showTitle.classList.add('text-yellow-600', 'font-bold', 'mt-4', 'text-center', 'movie-title', 'font-xl', 'text-pretty', 'line-clamp-2'); // Text truncation class for overflow handling

//         const showReleaseDate = document.createElement('p');
//         showReleaseDate.textContent = show.first_air_date || 'Release date not available';
//         showReleaseDate.classList.add('text-white', 'text-sm', 'mt-2', 'text-center', 'text-pretty', 'sm:mb-2', 'mb-1');


//         showCard.appendChild(showPoster);
//         showCard.appendChild(showTitle);
//         showCard.appendChild(showReleaseDate);
//         showDiv.appendChild(showCard)

//         showsResults.appendChild(showDiv);
//     });
// }










function displayShows(shows) {
    const showsResults = document.getElementById('shows-results');
    showsResults.innerHTML = '';

    shows.forEach(show => {
        const showDiv = document.createElement('div');
        showDiv.classList.add(
            'rounded-lg', 'overflow-hidden', 'shadow-lg', 'snap-center',
            'mr-2', 'ml-2', 'border', 'border-yellow-400', 'lg:mr-3', 'lg:ml-3'
        );

        // ✅ Wrap show in an <a> tag to make it clickable
        const showLink = document.createElement('a');
        showLink.href = `../Details/details.html?type=tv&id=${show.id}`;
        showLink.classList.add('block'); // Ensures the entire card is clickable

        const showCard = document.createElement('div');

        // Show poster
        const showPoster = document.createElement('img');
        showPoster.src = show.poster_path
            ? `https://image.tmdb.org/t/p/original${show.poster_path}`
            : 'https://via.placeholder.com/500x750?text=No+Poster';

        showPoster.alt = show.name;
        showPoster.classList.add('w-full', 'h-32', 'object-cover', 'hover:opacity-75', 'rounded-lg', 'sm:h-72');

        // Show title
        const showTitle = document.createElement('h3');
        showTitle.textContent = show.name;
        showTitle.classList.add('text-yellow-600', 'font-bold', 'mt-4', 'text-center', 'movie-title', 'text-xl', 'line-clamp-2');

        // Show release date
        const showReleaseDate = document.createElement('p');
        showReleaseDate.textContent = show.first_air_date || 'Release date not available';
        showReleaseDate.classList.add('text-white', 'text-sm', 'mt-2', 'text-center', 'sm:mb-2', 'mb-1');

        // Append elements
        showCard.appendChild(showPoster);
        showCard.appendChild(showTitle);
        showCard.appendChild(showReleaseDate);

        // ✅ Ensure clicking anywhere on the card opens the details page
        showLink.appendChild(showCard);
        showDiv.appendChild(showLink);
        showsResults.appendChild(showDiv);
    });
}












document.addEventListener('DOMContentLoaded', fetchShows);

//trending tv shows section ends