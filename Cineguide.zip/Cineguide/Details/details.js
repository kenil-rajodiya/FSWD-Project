const apiKey = '1789f687965581723d153630c6153e6b';
const detailsContainer = document.getElementById('details-container');
const extraMediaContainer = document.getElementById('extra-media-container');

function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

const type = getQueryParam('type'); // 'movie' or 'tv'
const id = getQueryParam('id'); // Movie/Show ID

async function fetchDetails() {
    if (!id || !type) {
        detailsContainer.innerHTML = '<p class="text-red-500 text-center">Invalid request.</p>';
        return;
    }

    const url = `https://api.themoviedb.org/3/${type}/${id}?api_key=${apiKey}&language=en-US`;

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data) {
            console.log(data);
            displayDetails(data);
            fetchAdditionalMedia();
        } else {
            detailsContainer.innerHTML = '<p class="text-yellow-400 text-center">No details found.</p>';
        }
    } catch (error) {
        console.error('Error fetching details:', error);
        detailsContainer.innerHTML = '<p class="text-red-500 text-center">Error fetching details.</p>';
    }
}

async function fetchAdditionalMedia() {
    if (!extraMediaContainer) {
        console.error("extraMediaContainer is missing in the HTML.");
        return;
    }

    const imagesUrl = `https://api.themoviedb.org/3/${type}/${id}/images?api_key=${apiKey}`;

    try {
        const imagesResponse = await fetch(imagesUrl);
        const imagesData = await imagesResponse.json();
        displayExtraMedia(imagesData);
    } catch (error) {
        console.error('Error fetching extra media:', error);
    }
}

function displayDetails(item) {
    detailsContainer.innerHTML = `
        <div class="flex flex-col md:flex-row items-center md:items-start gap-6">
            <img src="${item.poster_path ? `https://image.tmdb.org/t/p/original${item.poster_path}` : 'https://via.placeholder.com/500x750?text=No+Poster'}" 
                 alt="${item.title || item.name}" 
                 class="w-64 rounded-lg shadow-lg">
            <div class="text-left max-w-2xl">
                <h1 class="text-3xl font-bold text-yellow-400">${item.title || item.name}</h1>
                <p class="mt-2 text-gray-300 text-sm">
                    <strong>Release Date:</strong> ${item.release_date || item.first_air_date || 'Not Available'}
                </p>
                <p class="mt-2 text-gray-400">${item.overview || 'No description available.'}</p>
                <p class="mt-2 text-gray-300"><strong>Rating:</strong> ⭐ ${item.vote_average}/10</p>
                <p class="mt-2 text-gray-300"><strong>Genres:</strong> ${item.genres.map(g => g.name).join(', ') || 'N/A'}</p>
                <p class="mt-2 text-gray-300"><strong>Runtime:</strong> ${item.runtime ? item.runtime + ' min' : 'N/A'}</p>
                <p class="mt-2 text-gray-300"><strong>Status:</strong> ${item.status || 'N/A'}</p>
                <p class="mt-2 text-gray-300"><strong>Production Companies:</strong> ${item.production_companies.map(pc => pc.name).join(', ') || 'N/A'}</p>
                <div class="mt-4 flex gap-4">
                    <a href="https://www.justwatch.com/" target="_blank" class="px-6 py-3 bg-yellow-400 text-black font-bold rounded-lg shadow-lg hover:bg-yellow-500 transition">Watch Now</a>
                    <button class="px-6 py-3 bg-gray-700 text-white font-bold rounded-lg shadow-lg hover:bg-gray-600 transition">Add to Watchlist</button>
                </div>
            </div>
        </div>
    `;
}

function displayExtraMedia(imagesData) {
    if (!extraMediaContainer) return;

    let postersHtml = '';
    if (imagesData.backdrops && imagesData.backdrops.length > 0) {
        postersHtml = `
            <h2 class="text-2xl font-bold text-yellow-400 mt-6">More Scenes</h2>
            <div class="flex gap-4 overflow-x-scroll mt-2">
                ${imagesData.backdrops.slice(0, 10).map(img => `
                    <img src="https://image.tmdb.org/t/p/w500${img.file_path}" class="w-64 rounded shadow-lg">
                `).join('')}
            </div>
        `;
    }

    extraMediaContainer.innerHTML = postersHtml;
}

document.addEventListener("DOMContentLoaded", function () {
    fetchDetails();
});
