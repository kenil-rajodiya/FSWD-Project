document.addEventListener("DOMContentLoaded", function () {
    let form = document.querySelector("form");
    let pass1 = document.getElementById("password");
    let pass2 = document.getElementById("confirmPassword");

    form.addEventListener("submit", function (event) {
        if (pass1.value !== pass2.value) {
            event.preventDefault(); // Prevent form submission
            alert("Passwords do not match!");
            pass1.value = "";
            pass2.value = "";
        }
    });
});
